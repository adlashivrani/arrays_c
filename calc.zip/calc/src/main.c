int main()
{
   int num1;
   int num2;
   char operator;
   printf("\nEnter the expression:\n");
   scanf("%d %c %d", &num1, &operator, &num2);
   calculator(num1, operator, num2);  
   return 0;
}
