calculator(int num1, char operator, int num2)
 {
     switch (operator)
     {
         case '+':
             addition(num1, num2);/*passing arguments to addition function*/
             break;
         case '-':
             subtraction(num1, num2);/*passing arguments to subtraction function*/
             break;
         case '*':
             multiplication(num1, num2);/*passing arguments to multiplication function*/
             break;
         case '/':
             division(num1, num2);/*passing arguments to division function*/
             break;
         default:
             printf("\ninvalid integer input\n");
     }
 }
 void addition(int num1, int num2)
 {
     printf("\naddition: %d\n", num1 + num2);
 }
 void subtraction(int num1, int num2)
 {
     printf("\nsubtraction: %d\n", num1 - num2);
 }
 void multiplication(int num1, int num2)
 {
     printf("\nmultiplication: %d\n", num1 * num2);
 }
 void division(int num1, int num2)
 {
     printf("\ndivision: %d\n", num1 / num2);
 }
