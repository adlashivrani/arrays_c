#include<stdio.h>
void calculator(int, char, int);
void addition(int, int);
void subtraction(int, int);
void multiplication(int, int);
void division(int, int);
